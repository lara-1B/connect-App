export const notifications = [
    {
      title: 'Notification 1',
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et velit varius, interdum ipsum a, congue metus.',
      borderColor: 'rgba(75, 192, 192, 1)' // Example color
    },
    {
      title: 'Notification 2',
      text: 'Vestibulum auctor velit ut orci tristique, nec feugiat arcu tempor. Curabitur sit amet turpis vel lectus gravida ultricies.',
      borderColor: 'rgba(153, 102, 255, 1)' // Example color
    },
    {
      title: 'Notification 3',
      text: 'Quisque a nisi ac ante lacinia aliquet. Duis egestas dolor at orci vestibulum, nec condimentum nulla dapibus.',
      borderColor: 'rgba(255, 159, 64, 1)' // Example color
    },
    {
      title: 'Notification 4',
      text: 'Suspendisse potenti. Integer vel massa vel eros feugiat fermentum. Nulla facilisi. Sed non dui nec arcu pharetra tristique.',
      borderColor: 'rgba(255, 99, 132, 1)' // Example color
    },
    {
      title: 'Notification 5',
      text: 'Phasellus nec sapien vel est sagittis efficitur vel et justo. Donec eget urna ut sapien luctus consectetur.',
      borderColor: 'rgba(54, 162, 235, 1)' // Example color
    },
    {
      title: 'Notification 6',
      text: 'Mauris sit amet urna vel libero vehicula gravida. Integer vestibulum ex vel metus aliquet, sit amet auctor nunc faucibus.',
      borderColor: 'rgba(75, 192, 192, 1)' // Example color
    },
    {
      title: 'Notification 7',
      text: 'Nullam et justo vitae quam vestibulum lacinia. Aenean luctus dui non sapien condimentum, vel convallis nisi volutpat.',
      borderColor: 'rgba(153, 102, 255, 1)' // Example color
    },
    {
      title: 'Notification 8',
      text: 'Sed dictum erat at ligula egestas fringilla. Suspendisse in ligula vel odio hendrerit blandit vel id sapien.',
      borderColor: 'rgba(255, 159, 64, 1)' // Example color
    },
    {
      title: 'Notification 9',
      text: 'Praesent fermentum lacus non turpis convallis, eu dapibus eros gravida. Integer gravida turpis nec libero auctor.',
      borderColor: 'rgba(255, 99, 132, 1)' // Example color
    },
    {
      title: 'Notification 10',
      text: 'Etiam commodo augue in felis vehicula, ac consectetur nisl faucibus. Ut nec lacus non metus pharetra ultricies.',
      borderColor: 'rgba(54, 162, 235, 1)' // Example color
    }
  ];
  