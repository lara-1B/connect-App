import Highcharts from 'highcharts';
import HighchartsMap from 'highcharts/modules/map';
import mapData from '../Maps/in-all.geo.json'; 

HighchartsMap(Highcharts);

const mapDataWithSectors = [
    { id: 'IN.AN', value: 1, color: '#FF8480' }, // Andaman and Nicobar Islands
    { id: 'IN.AP', value: 2, color: '#165DC9' }, // Andhra Pradesh
    { id: 'IN.AR', value: 3, color: '#43C6BF' }, // Arunachal Pradesh
    { id: 'IN.AS', value: 4, color: '#722394' }, // Assam
    { id: 'IN.BR', value: 5, color: '#D98BCC' }, // Bihar
    { id: 'IN.CH', value: 1, color: '#FF8480' }, // Chandigarh
    { id: 'IN.CT', value: 2, color: '#165DC9' }, // Chhattisgarh
    { id: 'IN.DN', value: 3, color: '#43C6BF' }, // Dadra and Nagar Haveli and Daman and Diu
    { id: 'IN.DD', value: 4, color: '#722394' }, // Daman and Diu
    { id: 'IN.DL', value: 5, color: '#D98BCC' }, // Delhi
    { id: 'IN.GA', value: 1, color: '#FF8480' }, // Goa
    { id: 'IN.GJ', value: 2, color: '#165DC9' }, // Gujarat
    { id: 'IN.HR', value: 3, color: '#43C6BF' }, // Haryana
    { id: 'IN.HP', value: 4, color: '#722394' }, // Himachal Pradesh
    { id: 'IN.JK', value: 5, color: '#D98BCC' }, // Jammu and Kashmir
    { id: 'IN.JH', value: 1, color: '#FF8480' }, // Jharkhand
    { id: 'IN.KA', value: 2, color: '#165DC9' }, // Karnataka
    { id: 'IN.KL', value: 3, color: '#43C6BF' }, // Kerala
    { id: 'IN.LD', value: 4, color: '#722394' }, // Lakshadweep
    { id: 'IN.LA', value: 5, color: '#D98BCC' }, // Ladakh
    { id: 'IN.MP', value: 1, color: '#FF8480' }, // Madhya Pradesh
    { id: 'IN.MH', value: 2, color: '#165DC9' }, // Maharashtra
    { id: 'IN.Manipur', value: 3, color: '#43C6BF' }, // Manipur
    { id: 'IN.Mizoram', value: 4, color: '#722394' }, // Mizoram
    { id: 'IN.NG', value: 5, color: '#D98BCC' }, // Nagaland
    { id: 'IN.OR', value: 1, color: '#FF8480' }, // Odisha
    { id: 'IN.PB', value: 2, color: '#165DC9' }, // Punjab
    { id: 'IN.RJ', value: 3, color: '#43C6BF' }, // Rajasthan
    { id: 'IN.SK', value: 4, color: '#722394' }, // Sikkim
    { id: 'IN.TN', value: 5, color: '#D98BCC' }, // Tamil Nadu
    { id: 'IN.TG', value: 1, color: '#FF8480' }, // Telangana
    { id: 'IN.TR', value: 2, color: '#165DC9' }, // Tripura
    { id: 'IN.UT', value: 3, color: '#43C6BF' }, // Uttarakhand
    { id: 'IN.UP', value: 4, color: '#722394' }, // Uttar Pradesh
    { id: 'IN.WB', value: 5, color: '#D98BCC' }, // West Bengal
  ];
  
  const mapChartConfig = {
    chart: {
      map: mapData, 
      height: '90%', 
    },
    title: {
      text: 'Indian States by Sector',
    },
    mapNavigation: {
      enabled: false,
      buttonOptions: {
        verticalAlign: 'bottom',
      },
    },
    colorAxis: {
      dataClasses: [
        {
          from: 1,
          to: 1,
          color: '#FF8480', // Hex color for sector 1
          name: 'HealthCare Sector',

        },
        {
          from: 2,
          to: 2,
          color: '#165DC9', // Hex color for sector 2
          name: 'Construction Sector',
        },
        {
          from: 3,
          to: 3,
          color: '#43C6BF', // Hex color for sector 3
          name: 'Home Services Sector',
        },
        {
          from: 4,
          to: 4,
          color: '#722394', // Hex color for sector 4
          name: 'Petcare Sector',
        },
        {
          from: 5,
          to: 5,
          color: '#D98BCC', // Hex color for sector 5
          name: 'Entertainment Sector',
        },
        {
          from: 6,
          to: 6,
          color: '#FFD461', // Hex color for sector 6
          name: 'Event Sector',
        },
      ],
      labels: {
        format: '{value}', 
      },
    },
    series: [
      {
        data: mapDataWithSectors,
        mapData: mapData,
        joinBy: ['id', 'id'], // Ensure to use 'id' here
        name: 'Sectors',
        states: {
          hover: {
            color: '#BADA55',
          },
        },
        dataLabels: {
          enabled: false,
          format: '{point.name}',
        },
      },
    ],
};

export default mapChartConfig;

