import { Chart, registerables } from 'chart.js';

// Register Chart.js components
Chart.register(...registerables);

// Define a plugin to add percentage circles
const percentagePlugin = {
  id: 'percentagePlugin',
  afterDatasetsDraw(chart, args, options) {
    const { ctx, chartArea, data } = chart;

    if (!chartArea || !data || !data.datasets[0]) return;

    const dataset = data.datasets[0];
    const total = dataset.data.reduce((a, b) => a + b, 0);

    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 16px Arial'; // Adjust text size if needed

    dataset.data.forEach((value, index) => {
      const meta = chart.getDatasetMeta(0);
      const arc = meta.data[index];

      if (!arc) return;

      const { x, y, innerRadius, outerRadius, startAngle, endAngle } = arc;
      const midAngle = (startAngle + endAngle) / 2;
      const radius = (outerRadius + innerRadius) / 2;

      // Calculate the center of the arc
      const arcCenterX = x + (radius + 20) * Math.cos(midAngle);
      const arcCenterY = y + (radius + 20) * Math.sin(midAngle);

      // Draw percentage circle (doubled the radius)
      ctx.beginPath();
      ctx.arc(arcCenterX, arcCenterY, 20, 0, 2 * Math.PI); // Double the radius
      ctx.fillStyle = 'white'; // White color for the circle
      ctx.fill();

      // Draw percentage text (adjusted text size)
      ctx.fillStyle = '#000'; // Black text color for contrast
      ctx.fillText(Math.round((value / total) * 100) + '%', arcCenterX, arcCenterY); // No decimal places

      ctx.restore();
    });
  }
};

export default percentagePlugin;
