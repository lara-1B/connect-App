import { ArcElement, Tooltip, Legend } from 'chart.js';

// Configuration for the arc chart
export const arcConfig = (percent) => ({
  type: 'doughnut',
  data: {
    datasets: [
      {
        data: [percent, 100 - percent], // This dataset determines the arc length
        backgroundColor: ['rgba(75, 192, 192, 1)', 'rgba(204, 204, 204, 1)'], // Colors for the arc
        borderColor: ['rgba(75, 192, 192, 1)', 'rgba(204, 204, 204, 1)'],
        borderWidth: 1,
      },
    ],
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (tooltipItem) => `${tooltipItem.label}: ${tooltipItem.raw}%`,
        },
      },
    },
    elements: {
      arc: {
        borderWidth: 0, // No border on the arcs
        borderRadius: 0, // Standard arc shape (not circular)
      },
    },
    cutout: '50%', // Make it a semi-circle
    rotation: -Math.PI, // Start the arc from the left
    circumference: Math.PI, // 180 degrees
  },
});
