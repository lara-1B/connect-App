import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

export const chartOptionsNoLabels = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    x: {
      display: false, 
      type: 'category',
    },
    y: {
      display: false, 
      type: 'linear',
    },
  },
  plugins: {
    legend: {
      display: false, 
    },
    tooltip: {
      enabled: false, 
    },
  },
};

export const chartOptionsWithLabels = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    x: {
      display: true, 
    },
    y: {
      display: true, 
    },
  },
  plugins: {
    legend: {
      display: true, 
    },
    tooltip: {
      enabled: true, 
    },
  },
};

export const chartOptionsDonut = {
  responsive: true,
  maintainAspectRatio: false,
  cutout: '85%', 
  rotation: -135, 
  circumference: 270, 
  elements: {
    arc: {
      borderWidth: 0, 
      borderRadius: 10
    },
  },
  plugins: {
    legend: {
      display: false, 
    },
    tooltip: {
      enabled: false, 
    },
  },
};

export const chartOptionsBar = {
  responsive: true,
  maintainAspectRatio: false,

  scales: {
    x: {
      display: false, 
      stacked: true,
      grid: {
        borderColor: '#ddd', 
        borderDash: [5, 5],  
      },
    },
    y: {
      display: true, 
      stacked: true,
      ticks: {
        stepSize: 30,
        max: 150,
      },
      grid: {
        borderColor: '#ddd', 
        borderDash: [5, 5],  
      },
    },
  },

  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
      enabled: false,
    },
  },

  elements: {
    bar: {
      borderRadius: 15, 
    },
  },

  layout: {
    padding: {
      left: 10,  
      right: 10, 
      top: 20,   
      bottom: 20 
    },
  },
};


export const chartOptionsPie = {
  responsive: true,
  maintainAspectRatio: false,
  cutout: '0%', // Pie chart without cutout
  rotation: 0, // No rotation
  circumference: 360, // Full circle
  elements: {
    arc: {
      borderWidth: 2, // Border width for slices
      borderRadius: 5 // Rounded borders
    },
  },
  plugins: {
    legend: {
      display: false, // Hide legend if not needed
    },
    tooltip: {
      enabled: true, // Enable tooltips
    },
  },
};

export const chartOptionsWide = {
  scales: {
    x: {
      title: {
        display: true,
        text: 'Day of the Week'
      },
    },
    y: {
      title: {
        display: true,
        text: 'Value'
      },
      ticks: {
        stepSize: 1000,
        callback: (value) => `${value}`
      }
    }
  },
  plugins: {
    legend: {
      display: false,
      position: 'bottom'
    },
    tooltip: {
      callbacks: {
        label: (tooltipItem) => `${tooltipItem.dataset.label}: ${tooltipItem.raw}`
      }
    }
  }
};


export const chartOptionsCircle = {
  responsive: true,
  maintainAspectRatio: false,
  cutout: '0%', // Full circle, no cutout
  rotation: 0, // No rotation
  circumference: 360, // Full circle
  elements: {
    arc: {
      borderWidth: 2, // Border width for slices
      borderRadius: 5, // Rounded borders
    },
  },
  plugins: {
    legend: {
      display: false, // Hide legend if not needed
    },
    tooltip: {
      enabled: true, // Enable tooltips
    },
  },
};
export const chartOptionsServiceOfferingPie = {
  responsive: true,
  maintainAspectRatio: false,
  rotation: -135, // Rotate to align as needed
  circumference: 360, // Show a semi-circle (270 degrees)
  elements: {
    arc: {
      borderWidth: 0, // No border for a cleaner look
      borderRadius: 10, // Rounded corners
    },
  },
  plugins: {
    legend: {
      display: false, // Hide legend if not needed
    },
    tooltip: {
      enabled: true, // Disable tooltips for simplicity
    },
  },
};

export const chartOptionsServiceOfferingLine = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    x: {
      display: true, // Display x-axis labels
      title: {
        display: true,
        text: 'Month', // X-axis label
      },
      ticks: {
        autoSkip: true, // Skip some labels to avoid overlap
        maxTicksLimit: 12, // Limit the number of ticks to 12
      },
    },
    y: {
      display: true, // Display y-axis labels
      title: {
        display: true,
        text: 'Value', // Y-axis label
      },
    },
  },
  plugins: {
    legend: {
      display: false, // Display the legend
    },
    tooltip: {
      enabled: false, // Enable tooltips
    },
  },
};

export const chartDataServiceProviderDonut = {
  labels: ['HealthCare Sector', 'Construction Sector', 'Home Services Sector', 'Petcare Sector', 'Entertainment Sector', 'Event Sector'],
  datasets: [
    {
      data: [15, 25, 10, 20, 15, 15], // Example data
      backgroundColor: [
        '#FF6384', // HealthCare Sector
        '#36A2EB', // Construction Sector
        '#FFCE56', // Home Services Sector
        '#4BC0C0', // Petcare Sector
        '#F9A825', // Entertainment Sector
        '#F57C00', // Event Sector
      ],
      borderWidth: 1,
    },
  ],
};






export const chartDataDown = {
  labels: ['1', '2', '3', '4', '5', '6'],
  datasets: [
    {
      label: 'Total Sales',
      data: [50, 45, 60, 55, 70, 65], 
      borderColor: 'rgba(255, 99, 132, 1)', 
      borderWidth: 2,
      fill: false, 
      cubicInterpolationMode: 'monotone', 
    },
  ],
};

export const chartDataUp = {
    labels: ['1', '2', '3', '4', '5', '6'],

  datasets: [
    {
      label: 'Total Customers',
      data: [10, 7, 12, 11, 15, 20], 
      borderColor: 'rgba(75, 192, 192, 1)', 
      borderWidth: 2,
      fill: false,
      cubicInterpolationMode: 'monotone', 
    },
  ],
};

export const chartDataSlightUp = {
    labels: ['1', '2', '3', '4', '5', '6'],

  datasets: [
    {
      label: 'Total Orders',
      data: [10, 15, 12, 18, 14, 20],
      borderColor: 'rgba(255, 206, 86, 1)', 
      borderWidth: 2,
      fill: false,
      cubicInterpolationMode: 'monotone', 
    },
  ],
};

export const chartDataDonut = {
  labels: ['Completed', 'Remaining'],
  datasets: [{
    label: 'Order Status',
    data: [67, 33], 
    backgroundColor: ['rgba(74,58,255,255)', 'rgba(255, 255, 153, 1)'], 
    borderWidth: 0, 
  }],
};

export const chartDataBar = {
  labels: [
    'Active Service Provider',
    'Service Provider Retention Rate',
    'New Service Provider',
    'Service Completion Rate',
    'Total Service Provider',
    'Average Rating'
  ],
  datasets: [
    {
      label: 'Metrics',
      data: [100, 120, 135, 80, 25, 120],
      backgroundColor: (context) => {
        const index = context.dataIndex;
        const colors = [
          'rgba(255, 132, 124, 1)', 
          'rgba(22, 93, 201, 1)',   
          'rgba(67, 198, 191, 1)',  
          'rgba(114, 35, 145, 1)',  
          'rgba(217, 139, 207, 1)', 
          'rgba(255, 212, 97, 1)'   
        ];
        return colors[index % colors.length]; 
      },
      borderColor: (context) => {
        const index = context.dataIndex;
        const colors = [
          'rgba(255, 132, 124, 1)', 
          'rgba(22, 93, 201, 1)',   
          'rgba(67, 198, 191, 1)',  
          'rgba(114, 35, 145, 1)',  
          'rgba(217, 139, 207, 1)', 
          'rgba(255, 212, 97, 1)'   
        ];
        return colors[index % colors.length]; 
      },
      borderWidth: 1,
    }
  ],
};


export const chartDataPie = {
  labels: ['Completed', 'Remaining'],
  datasets: [
    {
      data: [85, 15], // 85% completed, 15% remaining
      backgroundColor: ['#4caf50', '#ffffff'], // Green for completed, white for remaining
      borderColor: ['#ffffff', '#ffffff'], // White border color
      borderWidth: 2,
    },
  ],
};

export const chartDataWide = {
  labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
  datasets: [
    {
      label: 'Active Service Provider',
      data: [1500, 3000, 1000, 4000, 2000, 3500, 1800], // Fluctuating data
      borderColor: '#FF5733', 
      backgroundColor: 'rgba(255, 87, 51, 0.2)', 
      fill: false,
    },
    {
      label: 'Service Provider Retention Rate',
      data: [800, 2500, 900, 2300, 600, 1800, 1000], // Fluctuating data
      borderColor: '#33FF57', 
      backgroundColor: 'rgba(51, 255, 87, 0.2)', 
      fill: false,
    },
    {
      label: 'New Service Provider',
      data: [700, 1200, 300, 2500, 1000, 1500, 600], // Fluctuating data
      borderColor: '#3357FF', 
      backgroundColor: 'rgba(51, 87, 255, 0.2)', 
      fill: false,
    },
    {
      label: 'Service Completion Rate',
      data: [2000, 4000, 1500, 3800, 1800, 3500, 1600], // Fluctuating data
      borderColor: '#F1C40F', 
      backgroundColor: 'rgba(241, 196, 15, 0.2)', 
      fill: false,
    },
    {
      label: 'Total Service Provider',
      data: [3500, 2000, 3800, 2500, 4100, 3000, 4000], // Fluctuating data
      borderColor: '#E74C3C', 
      backgroundColor: 'rgba(231, 76, 60, 0.2)', 
      fill: false,
    },
    {
      label: 'Average Rating',
      data: [3.5, 4.5, 3.2, 4.8, 3.9, 4.3, 4.1], // Fluctuating data
      borderColor: '#8E44AD', 
      backgroundColor: 'rgba(142, 68, 173, 0.2)', 
      fill: false,
    }
  ]
};

export const chartDataCircle = {
  labels: ['HealthCare Sector', 'Construction Sector', 'Home Services Sector', ' Petcare Sector', 'Entertainment Sector', 'Event Sector'],
  datasets: [
    {
      label: 'Segments',
      data: [15, 25, 20, 10, 5, 25], // Data values for each segment
      backgroundColor: [
        'rgba(255, 132, 124, 1)', // Color for Segment 1
        'rgba(22, 93, 201, 1)',   // Color for Segment 2
        'rgba(67, 198, 191, 1)',  // Color for Segment 3
        'rgba(114, 35, 145, 1)',  // Color for Segment 4
        'rgba(217, 139, 207, 1)', // Color for Segment 5
        'rgba(255, 212, 97, 1)'   // Color for Segment 6
      ],
      borderColor: [
        'rgba(255, 132, 124, 1)', // Border color for Segment 1
        'rgba(22, 93, 201, 1)',   // Border color for Segment 2
        'rgba(67, 198, 191, 1)',  // Border color for Segment 3
        'rgba(114, 35, 145, 1)',  // Border color for Segment 4
        'rgba(217, 139, 207, 1)', // Border color for Segment 5
        'rgba(255, 212, 97, 1)'   // Border color for Segment 6
      ],
      borderWidth: 2,
    }
  ],
};

export const chartDataServiceOfferingPie = {
  labels: ['Active Service', 'Service Added', 'Service Removed'],
  datasets: [
    {
      data: [70, 20, 10],
      backgroundColor: ['#4CAF50', '#FFC107', '#F44336'], // Green, Yellow, Red
      borderWidth: 0, // No border for the slices
    },
  ],
};
export const chartDataServiceOfferingLine = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // 12 months
  datasets: [
    {
      label: 'Active Service',
      data: [70, 80, 90, 70, 85, 95, 100, 90, 85, 75, 80, 70], // Example data
      borderColor: '#4CAF50', // Green color for the line
      backgroundColor: 'rgba(76, 175, 80, 0.5)', // Light green background
      fill: true, // Fill under the line
      tension: 0.4, // Smooth curves
      borderWidth: 2, // Line width
    },
    {
      label: 'Service Added',
      data: [50, 60, 70, 65, 70, 75, 80, 85, 90, 80, 75, 60], // Example data
      borderColor: '#FF5722', // Orange color for the line
      backgroundColor: 'rgba(255, 87, 34, 0.5)', // Light orange background
      fill: true, // Fill under the line
      tension: 0.4, // Smooth curves
      borderWidth: 2, // Line width
    },
    {
      label: 'Service Removed',
      data: [30, 20, 10, 15, 20, 25, 30, 35, 30, 25, 20, 15], // Example data
      borderColor: '#2196F3', // Blue color for the line
      backgroundColor: 'rgba(33, 150, 243, 0.5)', // Light blue background
      fill: true, // Fill under the line
      tension: 0.4, // Smooth curves
      borderWidth: 2, // Line width
    },
  ],
};


export const chartDataArc = {
  labels: ['Category 1', 'Category 2', 'Category 3', 'Category 4'],
  datasets: [
    {
      data: [25, 35, 20, 20], // Example data values
      backgroundColor: [
        '#FF6384', // Color for Category 1
        '#36A2EB', // Color for Category 2
        '#FFCE56', // Color for Category 3
        '#4BC0C0', // Color for Category 4
      ],
      borderColor: '#FFFFFF', // Border color for each slice
      borderWidth: 2, // Border width for each slice
    },
  ],
};





export const chartOptionsServiceProviderDonut = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false, // Hide the legend
    },
    tooltip: {
      enabled: true,
    },
    datalabels: {
      display: false, // Hide data labels on the chart
    },
  },
};


export const chartOptionsArc = {
  responsive: true,
  maintainAspectRatio: false,
  cutout: '50%', // Adjust cutout percentage for inner radius
  rotation: 0, // No rotation
  circumference: 360, // Full circle
  elements: {
    arc: {
      borderWidth: 2, // Border width for slices
      borderRadius: 5, // Rounded borders
    },
  },
  plugins: {
    legend: {
      display: true, // Display legend if needed
      position: 'bottom',
    },
    tooltip: {
      enabled: true, // Enable tooltips
    },
  },
};

export const otherChartOptions = chartOptionsWithLabels; 