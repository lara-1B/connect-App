import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.component.css';

const Sidebar = ({ isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      {/* Toggle Sidebar */}
      <div className="sidebar-item" onClick={toggleSidebar}>
        <i className='bx bx-menu'></i>
      </div>
      
      {/* Home Link */}
      <Link to="/" className="sidebar-item">
        <i className='bx bx-home'></i>
        <span>Home</span>
      </Link>
      
      {/* Dashboard Link */}
      <Link to="/service-provider" className="sidebar-item">
        <i className='bx bx-tachometer'></i>
        <span>Dashboard</span>
      </Link>
      
      {/* Messages (currently no link, update if needed) */}
      <div className="sidebar-item">
        <i className='bx bx-message'></i>
        <span>Messages</span>
      </div>

      {/* Spacer to push FAQ and Settings to the bottom */}
      <div className="spacer"></div>

      {/* FAQ Icon */}
      <div className="sidebar-item">
        <i className='bx bx-help-circle'></i>
        <span>FAQ</span>
      </div>
      
      {/* Settings Icon */}
      <div className="sidebar-item">
        <i className='bx bx-cog'></i>
        <span>Settings</span>
      </div>
    </div>
  );
};

export default Sidebar;
