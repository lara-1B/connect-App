import React from 'react';
import './Navbar.component.css';

const Navbar = ({ toggleSidebar }) => {
  return (
    <div className="navbar">
      {/* Search Bar */}
      <div className="search-container">
        <i className="bx bx-search search-icon"></i>
        <input type="text" placeholder="Search..." className="search-bar" />
      </div>

      {/* Navbar Right Items */}
      <div className="navbar-items">
        {/* Notification Icon */}
        <div className="icon-wrapper notifications">
          <i className="bx bx-bell"></i>
          <span className="counter">3</span> {/* Notification counter */}
        </div>

        {/* Messages Icon */}
        <div className="icon-wrapper messages">
          <i className="bx bx-message"></i>
          <span className="counter">7</span> {/* Message counter */}
        </div>

        {/* Settings Icon */}
        <div className="icon-wrapper settings">
          <i className="bx bx-cog"></i>
        </div>

        {/* User Section */}
        <div className="user-section">
          <i className="bx bx-user"></i>
          <span>Hi, John</span>
          <i className="bx bx-chevron-down"></i>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
