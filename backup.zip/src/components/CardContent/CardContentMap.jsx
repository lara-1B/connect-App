import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import mapChartConfig from '../../config/mapChart.config'; // Adjust the path if necessary
import './CardContent.css'; // Include CSS for styling

const CardContentMap = ({ headerText, mapData }) => {
  // Merge the mapData with the default configuration
  const chartOptions = {
    ...mapChartConfig,
    series: [
      {
        ...mapChartConfig.series[0],
        data: mapData, // Pass your data here
      },
    ],
  };

  return (
    <div className="card-content-half">
      <div className="header">
        {headerText}
      </div>
      <div className="content-container">
        <HighchartsReact
          highcharts={Highcharts}
          constructorType="mapChart"
          options={chartOptions}
        />
      </div>
    </div>
  );
};

export default CardContentMap;
